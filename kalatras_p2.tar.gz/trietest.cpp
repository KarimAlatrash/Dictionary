#include <iostream>
#include "Trie.h"
#include "illegal_exception.h"

using namespace std;

bool Is_Valid_Str(string test) {
    for(int i{0}; i<test.length(); i++) {
        if ( (int)test[i] <97 || (int)test[i] >122) {
            return false;
        }
    }
    return true;
}

int main() {

    string line;
    Trie new_t{};



    while(true) {

        if ( cin.eof() ) {
            break;
        }

        getline(cin,line);

        if(line=="exit"){
            break;
        }

        size_t pos=line.find(" ");
        string cmd=line.substr(0,pos);
        string obj= line.substr(pos+1, line.length()-1 ); // of the form "url-name" "url"

        if (cmd == "i") {
            try {
                if(!Is_Valid_Str(obj))
                    throw illegal_exception();
                new_t.insert_w(obj);
            }
            catch (illegal_exception& e){
                cout<<e.msg()<<endl;
            }

        }
        else if(cmd == "e"){
            try {
                if(!Is_Valid_Str(obj))
                    throw illegal_exception();
                new_t.delete_w(obj);
            }
            catch (illegal_exception& e){
                cout<<e.msg()<<endl;
            }
        }
        else if(cmd == "s"){
            try {
                if(!Is_Valid_Str(obj))
                    throw illegal_exception();
                new_t.search_w(obj, true);
            }
            catch (illegal_exception& e){
                cout<<e.msg()<<endl;
            }
        }
        else if(cmd == "print"){
            new_t.print();
        }
        else if(cmd == "autocomplete"){
            obj= obj.substr(0, obj.size()-1);
            new_t.autocomplete(obj);
        }
        else if(cmd == "empty"){
            if(new_t.is_empty())
                cout<<"empty 1"<<endl;
            else
                cout<<"empty 0"<<endl;
        }
        else if(cmd == "clear"){
            new_t.clear_trie();
            cout<<"success"<<endl;
        }
        else if(cmd == "size"){
            cout<<"number of words is "<<new_t.get_size()<<endl;
        }

    }


    return 0;


}


