//
// Created by Karim Alatrash on 2021-03-18.
//

#include "illegal_exception.h"
